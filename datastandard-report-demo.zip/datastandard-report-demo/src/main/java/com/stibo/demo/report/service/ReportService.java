package com.stibo.demo.report.service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Service;

import com.stibo.demo.report.model.Attribute;
import com.stibo.demo.report.model.AttributeGroup;
import com.stibo.demo.report.model.AttributeLink;
import com.stibo.demo.report.model.AttributeType;
import com.stibo.demo.report.model.Category;
import com.stibo.demo.report.model.Datastandard;

@Service
public class ReportService {
	public Stream<Stream<String>> report(Datastandard datastandard, String categoryId) {

		return Stream.of();
	}   

	public static List<List<String>> report1(){ 
		try {
			FileReader jsonFile=new FileReader("src\\test\\resources\\datastandard.json");
			JSONObject pFile=(JSONObject) new JSONParser().parse(jsonFile);

			Datastandard myDatastandard = new Datastandard();

			//Datastandard id
			//System.out.println((String)pFile.get("id"));
			myDatastandard.setId((String)pFile.get("id"));

			//Datastandard name
			myDatastandard.setName((String)pFile.get("name"));


			//Datastandard List of Categories
			List<Category> lOfC = new ArrayList<Category>();    	
			for(Object catElement:(List<Category>)pFile.get("categories")) {
				Category cat = new Category();
				JSONObject catObj=(JSONObject) catElement;

				cat.setId((String)catObj.get("id"));	//Category id
				cat.setName((String)catObj.get("name"));	//Category name

				//Category AttributeLinks
				List<AttributeLink> ListOfAL = new ArrayList<AttributeLink>();
				for(Object catAl: (List<AttributeLink>)catObj.get("attributeLinks")) {
					AttributeLink al = new AttributeLink();
					JSONObject catALObj = (JSONObject)catAl;
					al.setId((String)catALObj.get("id"));
					al.setOptional((Boolean)catALObj.get("optional"));
					ListOfAL.add(al);
				}
				cat.setAttributeLinks(ListOfAL);

				cat.setParentId((String)catObj.get("parentId"));	//Category parentid
				cat.setParentId((String)catObj.get("description"));		//Category description
				//System.out.println(cat);
				lOfC.add(cat);
			}
			myDatastandard.setCategories(lOfC);
			//System.out.println(lOfC);

			//Datastandard List of Attributes
			List<Attribute> lOfA = new ArrayList<Attribute>();    	
			for(Object AtElement:(List<Attribute>)pFile.get("attributes")) {
				Attribute at = new Attribute();
				JSONObject atObj = (JSONObject) AtElement;

				at.setId((String)atObj.get("id"));   //
				at.setName((String)atObj.get("name"));	//

				//Attribute List of AttributeLinks
				List<AttributeLink> ListOfAL = new ArrayList<AttributeLink>();
				if ((List<AttributeLink>)atObj.get("attributeLinks") != null) {
					for(Object atAl: (List<AttributeLink>)atObj.get("attributeLinks")) {
						AttributeLink al = new AttributeLink();
						JSONObject atALObj = (JSONObject)atAl;
						al.setId((String)atALObj.get("id"));
						al.setOptional((Boolean)atALObj.get("optional"));
						ListOfAL.add(al);
					}
					at.setAttributeLinks(ListOfAL);
				}

				at.setDescription((String)atObj.get("description"));	// 
				at.setGroupIds((List<String>)atObj.get("groupIds"));	//

				//Attribute AttributeType
				AttributeType attType = new AttributeType();
				JSONObject x = (JSONObject)atObj.get("type");
				attType.setId((String)x.get("id"));		//
				attType.setMultiValue((Boolean)x.get("multiValue"));	//

				at.setType(attType);

				lOfA.add(at);
			}
			myDatastandard.setAttributes(lOfA);

			//Datastandard AttributeGroups
			List<AttributeGroup> lOfAG = new ArrayList<AttributeGroup>();    	
			for(Object AtElement:(List<AttributeGroup>)pFile.get("attributeGroups")) {
				AttributeGroup atg = new AttributeGroup();
				JSONObject atObj=(JSONObject) AtElement;

				atg.setId((String)atObj.get("id"));
				atg.setName((String)atObj.get("name"));
				atg.setDescription((String)atObj.get("description"));
				lOfAG.add(atg);
			}
			myDatastandard.setAttributeGroups(lOfAG);

			List<List<String>> finalList = new ArrayList<List<String>>();

			List<Category> list_of_category = myDatastandard.getCategories();
			List<Attribute> list_of_att = myDatastandard.getAttributes();

			for (int i=0; i<list_of_category.size(); i++) {

				List<String> rowValues = new ArrayList<String>();
				rowValues.add(list_of_category.get(i).getName()); 

				if(!list_of_category.get(i).getAttributeLinks().get(0).getOptional()) {
					rowValues.add(list_of_att.get(i).getName()+"*");
				}else {
					rowValues.add(list_of_att.get(i).getName());
				}

				rowValues.add(list_of_att.get(i).getDescription());

				if (list_of_att.get(i).getType().getMultiValue())
				{
					String id = list_of_att.get(i).getAttributeLinks().get(0).getId();
					boolean f = false;
					for(Attribute x: list_of_att) {
						int b = 0;
						if (x.getId().equals(id)) {
							rowValues.add(list_of_att.get(i).getType().getId() + "{ " + x.getName()+"*" + " : " + x.getType().getId() + " }" + "[]");
							f = true;
							break;
						}
					}
					if(!f)
						rowValues.add(list_of_att.get(i).getType().getId() + "[]");
				}    			
				else
				{
					rowValues.add(list_of_att.get(i).getType().getId());
				}


				String s1 ="";
				for (String s : list_of_att.get(i).getGroupIds()) {
					s1 += s + " ";
				}
				rowValues.add(s1);
				finalList.add(rowValues);
			}

			return finalList;
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
}
