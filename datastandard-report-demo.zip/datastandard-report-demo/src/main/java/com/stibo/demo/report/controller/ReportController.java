package com.stibo.demo.report.controller;

import static java.util.stream.Collectors.joining;

import java.io.File;
import java.io.PrintWriter;
import java.net.URI;
import java.util.HashMap;
import java.util.List;

import javax.websocket.DeploymentException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.RequestEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.stibo.demo.report.model.AttributeLink;
import com.stibo.demo.report.model.Category;
import com.stibo.demo.report.model.Datastandard;
import com.stibo.demo.report.service.ReportService;

@RestController
public class ReportController {

	@Autowired
	ReportService reportService;

	//    private final RestTemplate restTemplate;
	//    private final ReportService reportService;

	//    @Autowired
	//    public ReportController(ReportService reportService, RestTemplateBuilder restTemplateBuilder) {
	//        this.reportService = reportService;
	//        this.restTemplate = restTemplateBuilder.build();
	//    }
	//@PathVariable String datastandardId, @PathVariable String categoryId, @RequestHeader String authorization
	//    @GetMapping(value = "/report/{datastandardId}/{categoryId}")
	//    public String report(@PathVariable String datastandardId, @PathVariable String categoryId, @RequestHeader String authorization) throws DeploymentException {
	//        URI uri = URI.create("https://tagglo-dev.io/api/datastandards/v1/datastandards/" + datastandardId);
	//        RequestEntity<Void> request = RequestEntity.get(uri).header("Authorization", authorization).build();
	//        //System.out.println("asdf");
	//        Datastandard datastandard = restTemplate.exchange(request, Datastandard.class).getBody();
	//        return reportService.report(datastandard, categoryId)
	//            // naive CSV conversion, assuming cells do not have quotes
	//            .map(row -> row.collect(joining("\",\"", "\"", "\""))).collect(joining("\n")); 
	//    }

	@GetMapping(value= "/report1")
	public void report1() {

		try {
			PrintWriter outputCSV = new PrintWriter(new File("doc\\datastandard.csv"));
			StringBuilder s = new StringBuilder();
			s.append("CategoryName");
			s.append(",");
			s.append("AttributeName");
			s.append(",");
			s.append("Description");
			s.append(",");
			s.append("Type");
			s.append(",");
			s.append("Groups");
			s.append("\r\n");
			List<List<String>> listOfList=reportService.report1();
			for (List<String> row : listOfList) {
				for (String cell : row) {
					System.out.println(cell);
					if(cell==null) {
						s.append("");
					}else {
						s.append(cell);
					}
					s.append(",");
				}
				s.append("\r\n");
			}
			outputCSV.write(s.toString());
			outputCSV.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
